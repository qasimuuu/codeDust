function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220,220,0,600);
  fill(00);
  ellipse(100,80,80,100);
  fill(100,200,0);
  rect(200, 200, 120, 60);
  
}